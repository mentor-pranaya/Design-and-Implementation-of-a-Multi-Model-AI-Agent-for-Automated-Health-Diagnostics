
from reference_ranges import REFERENCE_RANGES

def interpret_parameter(parameter, value):
    if value is None:
        return {"status": "Missing", "message": "Value missing or unreadable"}

    if parameter not in REFERENCE_RANGES:
        return {"status": "Unknown", "message": "No reference range found"}

    ref = REFERENCE_RANGES[parameter]
    min_v, max_v = ref["min"], ref["max"]

    if value < min_v:
        status = "Low"
    elif value > max_v:
        status = "High"
    else:
        status = "Normal"

    return {
        "value": value,
        "unit": ref["unit"],
        "status": status,
        "normal_range": f"{min_v} - {max_v}"
    }


def run_model_1(cleaned_data):
    return {p: interpret_parameter(p, v) for p, v in cleaned_data.items()}
