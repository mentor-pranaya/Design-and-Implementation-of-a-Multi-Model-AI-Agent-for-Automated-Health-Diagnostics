"""
app.py

FastAPI wrapper exposing REST endpoints for the blood report classifier.
Endpoints:
- GET / : serves the chat UI (HTML)
- POST /predict/json : accepts JSON body with 'values' (dict of parameter -> numeric), optional 'gender' and 'method' ('rule' or 'ml')
- POST /predict/text : accepts raw text payload (JSON {"text": "..."}) and optional method
- POST /predict/file : accepts multipart file upload (PDF or image) and optional form field 'method'

On startup the app trains models on synthetic data so ML endpoints are available.

Dependencies: fastapi, uvicorn, python-multipart (for file uploads)
"""
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional, Dict, Any
import os
import tempfile
import json

from blood_report_classifier import (
    generate_synthetic_data,
    train_per_parameter_classifiers,
    train_overall_classifier,
    process_input_source,
    chat_predict,
)


# Pydantic models for request validation
class PredictJsonRequest(BaseModel):
    values: Dict[str, Any]
    gender: Optional[str] = None
    method: str = "rule"


class PredictTextRequest(BaseModel):
    text: str
    method: str = "rule"

app = FastAPI(title="Blood Report Classifier API")

# Mount static files (served at /static/*)
# The index.html will be served at /static/index.html
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


# Serve static files and the chat UI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

# Mount static directory
if os.path.isdir("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/chat")
def chat_ui():
    """Serve a simple chat web UI for uploading reports and getting results."""
    html_path = os.path.join("templates", "chat.html")
    if os.path.exists(html_path):
        return FileResponse(html_path)
    return {"error": "chat UI not found"}


@app.on_event("startup")
def startup_train_models():
    """Train models once at startup and store them on the app state."""
    # To keep startup reasonably fast, use moderate sample size
    df = generate_synthetic_data(n_samples=1500)
    models, reports = train_per_parameter_classifiers(df)
    overall_pipeline, overall_report = train_overall_classifier(df)

    app.state.models = models
    app.state.overall_pipeline = overall_pipeline
    app.state.overall_report = overall_report
    app.state.trained = True


@app.get("/")
def root():
    """Serve the chat UI HTML."""
    index_path = os.path.join(static_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path, media_type="text/html")
    return {"status": "ok", "message": "Chat UI not found; use /docs for API docs"}


@app.post("/predict/json")
async def predict_json(request: PredictJsonRequest):
    """Accepts JSON body with 'values' dict of parameters and optional 'gender'."""
    try:
        models = getattr(app.state, "models", None)
        overall_pipeline = getattr(app.state, "overall_pipeline", None)
        # Convert values dict to proper types
        clean_values = {k: float(v) if v is not None else None for k, v in request.values.items()}
        res = chat_predict({**clean_values, "Gender": request.gender}, models=models, ml_method=request.method, overall_pipeline=overall_pipeline)
        return JSONResponse(content=res)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/predict/text")
async def predict_text(request: PredictTextRequest):
    """Accepts JSON body {"text": "..."} and returns parsed + classified results."""
    try:
        # Try to parse as JSON first
        try:
            json_data = json.loads(request.text)
            source = json_data
        except:
            # If not JSON, treat as raw text
            source = request.text
        
        models = getattr(app.state, "models", None)
        overall_pipeline = getattr(app.state, "overall_pipeline", None)
        res = chat_predict(source, models=models, ml_method=request.method, overall_pipeline=overall_pipeline)
        return JSONResponse(content=res)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/predict/file")
async def predict_file(file: UploadFile = File(...), method: str = Form("rule")):
    """Accepts an uploaded file (pdf/image/json)."""
    if not file.filename:
        raise HTTPException(status_code=400, detail="File is required")
    
    # Validate file extension
    allowed_exts = ('.pdf', '.jpg', '.jpeg', '.png', '.json')
    if not any(file.filename.lower().endswith(ext) for ext in allowed_exts):
        raise HTTPException(status_code=400, detail=f"Unsupported file type. Allowed: {', '.join(allowed_exts)}")
    
    try:
        content = await file.read()
        if not content:
            raise HTTPException(status_code=400, detail="File is empty")
        
        # Handle JSON files directly (parse as dict)
        if file.filename.lower().endswith('.json'):
            try:
                json_data = json.loads(content.decode('utf-8'))
                source = json_data
            except json.JSONDecodeError as e:
                raise HTTPException(status_code=400, detail=f"Invalid JSON file: {str(e)}")
        else:
            # For PDFs and images, save to temp file
            suffix = '.' + file.filename.split('.')[-1] if '.' in file.filename else ''
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(content)
                source = tmp.name

        models = getattr(app.state, "models", None)
        overall_pipeline = getattr(app.state, "overall_pipeline", None)
        res = chat_predict(source, models=models, ml_method=method, overall_pipeline=overall_pipeline)
        
        # Ensure all values are JSON serializable
        return {
            "values": res.get("values", {}),
            "gender": res.get("gender"),
            "per_parameter_labels": res.get("per_parameter_labels", {}),
            "overall_label_rule": res.get("overall_label_rule"),
            "overall_label_ml": res.get("overall_label_ml"),
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing file: {str(e)}")
    finally:
        # Clean up temp file if created
        if isinstance(source, str) and os.path.exists(source):
            try:
                os.unlink(source)
            except Exception:
                pass


# If running this module directly, start an Uvicorn server (useful for local testing):
if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=False)
