
import re

def clean_numeric_value(value):
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)

    value = str(value).strip()
    if value == "":
        return None

    match = re.search(r"[-+]?[0-9]*\.?[0-9]+", value)
    if match:
        return float(match.group())
    return None


def clean_patient_data(raw_data):
    cleaned = {}
    errors = {}

    for param, value in raw_data.items():
        cleaned_value = clean_numeric_value(value)
        if cleaned_value is None:
            errors[param] = "Missing or invalid value"
        cleaned[param] = cleaned_value

    return cleaned, errors
