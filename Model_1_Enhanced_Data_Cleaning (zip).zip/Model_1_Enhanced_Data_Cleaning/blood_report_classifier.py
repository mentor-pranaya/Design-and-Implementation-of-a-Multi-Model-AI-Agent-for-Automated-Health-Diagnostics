"""
blood_report_classifier.py

Production-ready module that:
- Labels 20 blood parameters as Low/Normal/High (gender-specific for Haemoglobin)
- Generates synthetic sample data with realistic distributions
- Preprocesses data (missing values imputed, outliers capped)
- Trains per-parameter multi-class classifiers (Random Forest) using stratified splits
- Trains an overall health-status classifier and computes feature importances
- Evaluates models (accuracy, precision, recall, F1, confusion matrix)
- Provides a prediction function for new blood reports (rule-based and ML-based)

Dependencies: pandas, numpy, scikit-learn
"""

from typing import Dict, Any, Tuple, List
from collections import Counter
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import warnings

warnings.filterwarnings("ignore")

# -------------- Constants: parameter names and reference thresholds --------------
PARAMETERS = [
    "Haemoglobin",
    "RBC_count",
    "WBC_count",
    "Platelet_count",
    "Haematocrit",
    "FBS",
    "PPBS",
    "Total_Cholesterol",
    "LDL",
    "HDL",
    "Creatinine",
    "BUN",
    "Uric_Acid",
    "SGOT",
    "SGPT",
    "ALP",
    "Total_Bilirubin",
    "Direct_Bilirubin",
    "Albumin",
    "Total_Protein",
]

# Thresholds and classification logic for each parameter. Values follow user's reference.
# We store 'low' and 'normal' ranges (min, max), and 'high' thresholds where applicable.
# Some parameters have only 'normal' and 'high' (we infer 'low' when below normal min).
THRESHOLDS = {
    # Haemoglobin: depends on gender -> handle separately
    "RBC_count": {"low": 4.0, "normal_min": 4.0, "normal_max": 5.5, "high": 5.5},
    "WBC_count": {"low": 4000, "normal_min": 4000, "normal_max": 11000, "high": 11000},
    "Platelet_count": {"low": 150000, "normal_min": 150000, "normal_max": 450000, "high": 450000},
    "Haematocrit": {"low": 36, "normal_min": 36, "normal_max": 50, "high": 50},
    "FBS": {"low": 70, "normal_min": 70, "normal_max": 99, "high": 126},
    "PPBS": {"low": 70, "normal_min": 0, "normal_max": 139, "high": 200},
    # Total Cholesterol: merge Borderline High into High for Low/Normal/High mapping
    "Total_Cholesterol": {"low": 0, "normal_min": 0, "normal_max": 199, "high": 240},
    "LDL": {"low": 0, "normal_min": 0, "normal_max": 99, "high": 160},
    "HDL": {"low": 40, "normal_min": 40, "normal_max": 60, "high": 60},
    "Creatinine": {"low": 0.6, "normal_min": 0.6, "normal_max": 1.3, "high": 1.3},
    "BUN": {"low": 7, "normal_min": 7, "normal_max": 20, "high": 20},
    "Uric_Acid": {"low": 3, "normal_min": 3, "normal_max": 7, "high": 7},
    "SGOT": {"low": 10, "normal_min": 10, "normal_max": 40, "high": 40},
    "SGPT": {"low": 7, "normal_min": 7, "normal_max": 56, "high": 56},
    "ALP": {"low": 44, "normal_min": 44, "normal_max": 147, "high": 147},
    "Total_Bilirubin": {"low": 0.3, "normal_min": 0.3, "normal_max": 1.2, "high": 1.2},
    "Direct_Bilirubin": {"low": 0.0, "normal_min": 0.0, "normal_max": 0.3, "high": 0.3},
    "Albumin": {"low": 3.5, "normal_min": 3.5, "normal_max": 5.0, "high": 5.0},
    "Total_Protein": {"low": 6.0, "normal_min": 6.0, "normal_max": 8.3, "high": 8.3},
}

LABELS = ["Low", "Normal", "High"]

# -------------- Utility: classification rule per parameter --------------

def classify_param(name: str, value: float, gender: str = None) -> str:
    """
    Classify a single value into Low/Normal/High according to thresholds.
    For Haemoglobin, we apply gender-specific thresholds.
    """
    if pd.isna(value):
        return "Normal"  # conservative neutral label for missing values

    # Haemoglobin special handling with gender-specific thresholds
    if name == "Haemoglobin":
        if gender == "F":
            if value < 12:
                return "Low"
            elif value <= 15:
                return "Normal"
            else:
                return "High"
        elif gender == "M":
            if value < 13:
                return "Low"
            elif value <= 17:
                return "Normal"
            else:
                return "High"
        else:
            # fallback for missing gender
            if value < 12.5:
                return "Low"
            elif value <= 16:
                return "Normal"
            else:
                return "High"

    # Generic parameters using THRESHOLDS
    thr = THRESHOLDS.get(name)
    if thr is None:
        return "Normal"

    if value < thr["low"]:
        return "Low"
    elif value <= thr["normal_max"]:
        return "Normal"
    else:
        return "High"


# -------------- Synthetic data generation for demonstration --------------

def generate_synthetic_data(n_samples: int = 3000, random_state: int = 42) -> pd.DataFrame:
    """
    Generates a DataFrame with n_samples rows and the 20 parameter numeric columns plus 'Gender'.
    Values are sampled from realistic distributions and then clipped to plausible ranges.
    """
    np.random.seed(random_state)
    data = {}

    # Gender distribution
    data["Gender"] = np.random.choice(["M", "F"], size=n_samples, p=[0.5, 0.5])

    # Distribution heuristics (mean, sd) - chosen to produce a realistic mix of Normal/Low/High
    data["Haemoglobin"] = np.where(
        np.array(data["Gender"]) == "M",
        np.random.normal(loc=15, scale=1.0, size=n_samples),  # men
        np.random.normal(loc=13.5, scale=1.0, size=n_samples),  # women
    )

    data["RBC_count"] = np.random.normal(loc=4.7, scale=0.3, size=n_samples)
    data["WBC_count"] = np.random.normal(loc=7000, scale=2500, size=n_samples)
    data["Platelet_count"] = np.random.normal(loc=250000, scale=50000, size=n_samples)
    data["Haematocrit"] = np.random.normal(loc=42, scale=3.5, size=n_samples)
    data["FBS"] = np.random.normal(loc=95, scale=20, size=n_samples)
    data["PPBS"] = np.random.normal(loc=130, scale=45, size=n_samples)
    data["Total_Cholesterol"] = np.random.normal(loc=190, scale=40, size=n_samples)
    data["LDL"] = np.random.normal(loc=110, scale=35, size=n_samples)
    data["HDL"] = np.random.normal(loc=50, scale=12, size=n_samples)
    data["Creatinine"] = np.random.normal(loc=1.0, scale=0.25, size=n_samples)
    data["BUN"] = np.random.normal(loc=15, scale=5, size=n_samples)
    data["Uric_Acid"] = np.random.normal(loc=5.0, scale=1.2, size=n_samples)
    data["SGOT"] = np.random.normal(loc=28, scale=10, size=n_samples)
    data["SGPT"] = np.random.normal(loc=30, scale=12, size=n_samples)
    data["ALP"] = np.random.normal(loc=85, scale=20, size=n_samples)
    data["Total_Bilirubin"] = np.random.normal(loc=0.8, scale=0.3, size=n_samples)
    data["Direct_Bilirubin"] = np.random.normal(loc=0.15, scale=0.1, size=n_samples)
    data["Albumin"] = np.random.normal(loc=4.2, scale=0.4, size=n_samples)
    data["Total_Protein"] = np.random.normal(loc=7.0, scale=0.6, size=n_samples)

    df = pd.DataFrame(data)

    # Clip values to plausible physiological bounds
    clip_values = {
        "Haemoglobin": (6, 22),
        "RBC_count": (2.0, 7.0),
        "WBC_count": (1000, 40000),
        "Platelet_count": (20000, 1000000),
        "Haematocrit": (20, 65),
        "FBS": (30, 400),
        "PPBS": (30, 500),
        "Total_Cholesterol": (100, 400),
        "LDL": (20, 260),
        "HDL": (10, 120),
        "Creatinine": (0.2, 5.0),
        "BUN": (2, 100),
        "Uric_Acid": (1, 15),
        "SGOT": (5, 400),
        "SGPT": (5, 400),
        "ALP": (20, 500),
        "Total_Bilirubin": (0.1, 5.0),
        "Direct_Bilirubin": (0.01, 3.0),
        "Albumin": (1.0, 6.0),
        "Total_Protein": (4.0, 10.0),
    }

    for col, (lowc, highc) in clip_values.items():
        df[col] = df[col].clip(lower=lowc, upper=highc)

    # Introduce some realistic missingness (1-2% per column)
    for col in PARAMETERS:
        df.loc[df.sample(frac=0.02, random_state=random_state).index, col] = np.nan

    # Create parameter labels using classification rules
    for param in PARAMETERS:
        df[f"{param}_label"] = df.apply(
            lambda r: classify_param(param, r[param], r.get("Gender")), axis=1
        )

    return df


# -------------- Preprocessing --------------

def preprocess_features(df: pd.DataFrame) -> Tuple[pd.DataFrame, SimpleImputer]:
    """
    Impute missing numeric values (median) and cap outliers using 1st/99th percentiles.
    Returns processed feature DataFrame and the fitted imputer for later use on new samples.
    """
    numeric_cols = PARAMETERS.copy()
    X = df[numeric_cols].copy()

    # Cap outliers per column at 1st and 99th percentiles
    for col in numeric_cols:
        lower, upper = np.nanpercentile(X[col], [1, 99])
        X[col] = X[col].clip(lower=lower, upper=upper)

    # Median imputation
    imputer = SimpleImputer(strategy="median")
    X_imputed = pd.DataFrame(imputer.fit_transform(X), columns=numeric_cols)

    return X_imputed, imputer


# -------------- Build, train and evaluate per-parameter classifiers --------------

def train_per_parameter_classifiers(
    df: pd.DataFrame, random_state: int = 42
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    For each parameter, train a RandomForestClassifier to predict its Low/Normal/High label.
    Uses stratified splitting on the parameter's label to maintain class distributions.

    Returns a dict of trained models and evaluation reports.
    """
    models = {}
    reports = {}

    X, imputer = preprocess_features(df)

    # Use numeric features (including the parameter itself) for prediction
    for param in PARAMETERS:
        y = df[f"{param}_label"].values

        # drop rows where target is missing
        mask = ~pd.isna(y)
        X_param = X[mask]
        y_param = y[mask]

        # Check class counts to decide whether stratified split is viable
        vc = pd.Series(y_param).value_counts()
        stratify_input = None
        if len(vc) > 1 and vc.min() >= 2:
            stratify_input = y_param
        else:
            # If any class has fewer than 2 samples, stratify will fail; fallback to non-stratified split
            print(f"Warning: parameter '{param}' has small class counts {vc.to_dict()}, using non-stratified split.")

        X_train, X_test, y_train, y_test = train_test_split(
            X_param, y_param, test_size=0.25, random_state=random_state, stratify=stratify_input
        )

        clf = RandomForestClassifier(n_estimators=150, random_state=random_state, class_weight="balanced")
        clf.fit(X_train, y_train)

        # Evaluate
        y_pred = clf.predict(X_test)
        report = classification_report(y_test, y_pred, zero_division=0, output_dict=True)
        cm = confusion_matrix(y_test, y_pred, labels=LABELS)

        models[param] = {
            "model": clf,
            "imputer": imputer,
            "X_test": X_test,
            "y_test": y_test,
            "y_pred": y_pred,
        }

        reports[param] = {
            "classification_report": report,
            "confusion_matrix": cm,
            "accuracy": report.get("accuracy", 0),
        }

    return models, reports


# -------------- Compute an overall health status label and train a model for it --------------

def compute_overall_status(df: pd.DataFrame) -> pd.Series:
    """
    Derive an overall status label (Low/Normal/High) from individual parameter labels.

    Rule implemented:
    - Count number of parameters classified as High (count_high) and Low (count_low)
    - If count_high >= 3 and count_high > count_low -> 'High'
    - Else if count_low >= 3 and count_low > count_high -> 'Low'
    - Else -> 'Normal'

    This provides a simple but interpretable overall health class.
    """
    label_cols = [f"{p}_label" for p in PARAMETERS]

    def row_label(row):
        counts = row[label_cols].value_counts()
        count_high = int(counts.get("High", 0))
        count_low = int(counts.get("Low", 0))
        if count_high >= 3 and count_high > count_low:
            return "High"
        if count_low >= 3 and count_low > count_high:
            return "Low"
        return "Normal"

    return df.apply(row_label, axis=1)


def train_overall_classifier(df: pd.DataFrame, random_state: int = 42) -> Tuple[Any, Dict[str, Any]]:
    """
    Trains a RandomForest classifier to predict the derived overall status from numeric parameters.
    Returns the trained pipeline and an evaluation report including feature importances.
    """
    X, imputer = preprocess_features(df)
    y_overall = compute_overall_status(df)

    # Stratified split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_overall, test_size=0.25, random_state=random_state, stratify=y_overall
    )

    pipeline = Pipeline([
        ("scaler", StandardScaler()),  # not strictly necessary for tree models but OK
        ("clf", RandomForestClassifier(n_estimators=200, random_state=random_state, class_weight="balanced")),
    ])

    pipeline.fit(X_train, y_train)
    y_pred = pipeline.predict(X_test)

    report = classification_report(y_test, y_pred, output_dict=True, zero_division=0)
    cm = confusion_matrix(y_test, y_pred, labels=["Low", "Normal", "High"])

    # Feature importances from the RandomForest inside pipeline
    importances = pipeline.named_steps["clf"].feature_importances_
    feat_importances = pd.Series(importances, index=X.columns).sort_values(ascending=False)

    eval_report = {
        "classification_report": report,
        "confusion_matrix": cm,
        "feature_importances": feat_importances,
    }

    return pipeline, eval_report


# -------------- Prediction function for new reports --------------

def predict_report(
    report: Dict[str, float],
    gender: str = None,
    models: Dict[str, Any] = None,
    method: str = "rule",
) -> Dict[str, str]:
    """
    Accepts a dict of parameter values (keys are parameter names; missing keys are allowed).
    method='rule' uses deterministic threshold rules; method='ml' uses trained per-parameter models (models must be provided).

    Returns a dict parameter -> label (Low/Normal/High)
    """
    out = {}

    if method == "rule":
        for p in PARAMETERS:
            val = report.get(p)
            out[p] = classify_param(p, val, gender)
        return out

    elif method == "ml":
        if models is None:
            raise ValueError("models dict is required when method='ml'")

        # Build feature vector
        x = pd.DataFrame([report], columns=PARAMETERS)

        # For each parameter's model, impute using the model's imputer and predict
        for p in PARAMETERS:
            model_info = models.get(p)
            if model_info is None:
                out[p] = "Normal"
                continue
            imputer = model_info["imputer"]
            x_imputed = pd.DataFrame(imputer.transform(x), columns=PARAMETERS)
            pred = model_info["model"].predict(x_imputed)[0]
            out[p] = pred
        return out

    else:
        raise ValueError("Unsupported method; choose 'rule' or 'ml'")


# -------------- OCR and text parsing utilities --------------
# These are optional utilities to allow the module to be used in a chatbot that accepts
# PDF, image, or JSON blood reports. They attempt to extract text and parse numeric
# values for each parameter so the classifier can process them.

try:
    import pytesseract
    from PIL import Image
    _HAS_PYTESSERACT = True
except Exception:
    _HAS_PYTESSERACT = False

try:
    import pdfplumber
    _HAS_PDFPLUMBER = True
except Exception:
    _HAS_PDFPLUMBER = False

try:
    from pdf2image import convert_from_path
    _HAS_PDF2IMAGE = True
except Exception:
    _HAS_PDF2IMAGE = False

import re
import json
import os

SYNONYMS = {
    "Haemoglobin": [r"haemoglobin", r"hemoglobin", r"hb\b"],
    "RBC_count": [r"rbc", r"rbc count"],
    "WBC_count": [r"wbc", r"wbc count"],
    "Platelet_count": [r"platelet", r"platelet count", r"plt\b"],
    "Haematocrit": [r"haematocrit", r"hematocrit", r"pcv\b"],
    "FBS": [r"fbs", r"fasting blood sugar", r"fasting glucose"],
    "PPBS": [r"ppbs", r"post[- ]prandial", r"post prandial"],
    "Total_Cholesterol": [r"total cholesterol", r"cholesterol"],
    "LDL": [r"ldl"],
    "HDL": [r"hdl"],
    "Creatinine": [r"creatinine"],
    "BUN": [r"bun", r"blood urea"],
    "Uric_Acid": [r"uric acid"],
    "SGOT": [r"sgot", r"ast"],
    "SGPT": [r"sgpt", r"alt"],
    "ALP": [r"alp", r"alkaline phosphatase"],
    "Total_Bilirubin": [r"total bilirubin"],
    "Direct_Bilirubin": [r"direct bilirubin"],
    "Albumin": [r"albumin"],
    "Total_Protein": [r"total protein"],
}

_NUM_RE = re.compile(r"([-+]?[0-9]*\.?[0-9]+)")


def extract_text_from_image(image_path: str) -> str:
    """
    Extract text from an image using pytesseract. Returns extracted text.
    Requires Tesseract and pytesseract; raises RuntimeError if not available.
    """
    if not _HAS_PYTESSERACT:
        raise RuntimeError("pytesseract or Pillow is not installed; OCR not available")
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img)
    return text


def extract_text_from_pdf(pdf_path: str) -> str:
    """
    Extract text from PDF. Uses pdfplumber if available; otherwise falls back to rendering pages
    as images and applying OCR (pdf2image + pytesseract). Returns concatenated text for all pages.
    """
    if _HAS_PDFPLUMBER:
        text_parts = []
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                text_parts.append(page.extract_text() or "")
        return "\n".join(text_parts)

    # Fallback to rendering pages as images
    if not (_HAS_PDF2IMAGE and _HAS_PYTESSERACT):
        raise RuntimeError("pdfplumber unavailable and pdf2image/pytesseract not available; cannot extract PDF text")
    images = convert_from_path(pdf_path)
    text_parts = []
    for img in images:
        text_parts.append(pytesseract.image_to_string(img))
    return "\n".join(text_parts)


def parse_report_text(text: str) -> Tuple[Dict[str, float], str]:
    """
    Parse extracted text to find numeric values for the known parameters.
    Returns (values_dict, gender)
    """
    # Normalize text: lowercasing and remove thousand separators (commas inside numbers)
    text_l = text.lower()
    text_l = re.sub(r"(?<=\d),(?=\d)", "", text_l)

    # detect gender
    gender = None
    if re.search(r"\bmale\b|\bm\.?\b|sex:\s*male", text_l):
        gender = "M"
    if re.search(r"\bfemale\b|\bf\.?\b|sex:\s*female", text_l):
        gender = "F"

    values = {p: None for p in PARAMETERS}

    # pattern for numbers (integers or decimals)
    num_pat = r"([0-9]+\.?[0-9]*)"

    # For each parameter, try synonyms and capture numbers nearby
    for p, syns in SYNONYMS.items():
        for syn in syns:
            # look for e.g. 'hb: 13.5' or 'haemoglobin 13.5' or 'hb 13.5 g/dl'
            pattern = rf"({syn})[^\d\n\r\:]*[:\-\s]*{num_pat}"
            m = re.search(pattern, text_l)
            if m:
                try:
                    values[p] = float(m.group(2))
                except Exception:
                    values[p] = None
                break

        # If still not found, attempt to find first standalone number near the synonym word
        if values[p] is None:
            for syn in syns:
                idx = text_l.find(syn)
                if idx != -1:
                    # search forward for first number within next 60 chars
                    m2 = re.search(num_pat, text_l[idx : idx + 60])
                    if m2:
                        values[p] = float(m2.group(1))
                        break
    return values, gender


def process_input_source(source: Any) -> Tuple[Dict[str, float], str]:
    """
    Accepts a file path (image/pdf/json) or a string (raw text) or a dict (JSON-like) and returns
    parsed numeric values and detected gender.
    """
    if isinstance(source, dict):
        # assume keys are parameters optionally including 'Gender'
        vals = {p: float(source.get(p)) if source.get(p) is not None else None for p in PARAMETERS}
        gender = source.get("Gender") or source.get("gender")
        if gender is not None:
            gender = gender[0].upper()
        return vals, gender

    if isinstance(source, str):
        # Check if it's a file path
        if os.path.exists(source):
            lower_path = source.lower()
            if lower_path.endswith('.json'):
                # Load JSON file
                try:
                    with open(source, 'r') as f:
                        json_data = json.load(f)
                    return process_input_source(json_data)  # Recursive call with dict
                except Exception as e:
                    print(f"Warning: failed to parse JSON file: {e}")
                    return {p: None for p in PARAMETERS}, None
            elif lower_path.endswith('.pdf'):
                text = extract_text_from_pdf(source)
                return parse_report_text(text)
            elif lower_path.endswith(('.png', '.jpg', '.jpeg')):
                text = extract_text_from_image(source)
                return parse_report_text(text)
        
        # Treat as raw text
        return parse_report_text(source)

    raise ValueError("Unsupported source type; provide dict, file path string, or raw text string")


def chat_predict(
    source: Any,
    models: Dict[str, Any] = None,
    ml_method: str = "rule",
    overall_pipeline: Any = None,
) -> Dict[str, Any]:
    """
    High-level function to be used in a chatbot-like interface.
    - `source` can be a dict (json), raw text, image path, or pdf path
    - `ml_method` selects whether to use rule-based or per-parameter ML models for labeling
    - `overall_pipeline` is an optional trained pipeline to predict overall health

    Returns a structured dict with per-parameter labels and overall status.
    All numeric values are cleaned (NaN -> None) for JSON serialization.
    """
    vals, gender = process_input_source(source)

    # Clean values: convert NaN to None for JSON serialization
    clean_vals = {}
    for k, v in vals.items():
        if v is None:
            clean_vals[k] = None
        elif pd.isna(v):
            clean_vals[k] = None
        else:
            clean_vals[k] = float(v)

    per_param_labels = predict_report(clean_vals, gender=gender, models=models, method=ml_method)

    overall = compute_overall_status(pd.DataFrame([{**{f"{p}_label": l for p, l in per_param_labels.items()}}]))[0]

    overall_ml = None
    if overall_pipeline is not None:
        X = pd.DataFrame([clean_vals])
        try:
            overall_ml = overall_pipeline.predict(X)[0]
        except Exception:
            overall_ml = None

    return {
        "values": clean_vals,
        "gender": gender,
        "per_parameter_labels": per_param_labels,
        "overall_label_rule": overall,
        "overall_label_ml": overall_ml,
    }

# -------------- Summary function to display top predictive parameters for overall health --------------

def summarize_feature_importance(feat_importances: pd.Series, top_n: int = 8) -> pd.DataFrame:
    """
    Returns top_n parameters most predictive of overall health status.
    """
    return feat_importances.head(top_n).reset_index().rename(columns={"index": "parameter", 0: "importance"})


# -------------- Example CLI usage and demonstration --------------

def run_demo():
    print("Generating synthetic data...")
    df = generate_synthetic_data(n_samples=3000)
    print("Preprocessing and training per-parameter classifiers...")

    models, param_reports = train_per_parameter_classifiers(df)

    # Example: show accuracy for each param
    accs = {p: param_reports[p]["accuracy"] for p in PARAMETERS}
    acc_series = pd.Series(accs).sort_values()
    print("Per-parameter accuracies (sample):")
    print(acc_series.tail(6))

    print("Training overall health classifier and computing feature importances...")
    overall_pipeline, overall_report = train_overall_classifier(df)
    print("Overall classification report (summary):")
    print(pd.DataFrame(overall_report["classification_report"]).T[["precision", "recall", "f1-score"]])

    top_predictors = summarize_feature_importance(overall_report["feature_importances"], top_n=8)
    print("Top predictors for overall health status:")
    print(top_predictors)

    # Demonstrate prediction
    sample = df.sample(1, random_state=1).to_dict(orient="records")[0]
    sample_values = {p: sample[p] for p in PARAMETERS}
    sample_gender = sample["Gender"]

    print("Sample deterministic (rule-based) labels:")
    print(predict_report(sample_values, gender=sample_gender, method="rule"))

    print("Sample ML-based labels:")
    ml_pred = predict_report(sample_values, gender=sample_gender, models=models, method="ml")
    print(ml_pred)

    print("Done.")


if __name__ == "__main__":
    run_demo()
