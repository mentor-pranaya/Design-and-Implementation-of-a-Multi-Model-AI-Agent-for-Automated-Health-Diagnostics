const chat = document.getElementById('chat');
const mode = document.getElementById('mode');
const fileInput = document.getElementById('fileInput');
const textInput = document.getElementById('textInput');
const jsonInput = document.getElementById('jsonInput');
const sendBtn = document.getElementById('send');
const methodSelect = document.getElementById('method');

function addMessage(sender, text) {
  const div = document.createElement('div');
  div.className = 'msg ' + (sender === 'user' ? 'user' : 'bot');
  div.innerHTML = `<strong>${sender}:</strong> <pre>${text}</pre>`;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

mode.addEventListener('change', () => {
  const m = mode.value;
  fileInput.classList.toggle('hidden', m !== 'file');
  textInput.classList.toggle('hidden', m !== 'text');
  jsonInput.classList.toggle('hidden', m !== 'json');
});

sendBtn.addEventListener('click', async () => {
  const m = mode.value;
  const method = methodSelect.value;
  addMessage('user', `Using mode=${m}, method=${method}`);

  try {
    if (m === 'file') {
      const fileEl = document.getElementById('file');
      if (!fileEl.files.length) return alert('Choose a file');
      const fd = new FormData();
      fd.append('file', fileEl.files[0]);
      fd.append('method', method);

      const r = await fetch('/predict/file', { method: 'POST', body: fd });
      const j = await r.json();
      addMessage('bot', JSON.stringify(j, null, 2));
    } else if (m === 'text') {
      const txt = document.getElementById('text').value;
      const r = await fetch('/predict/text', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: txt, method }) });
      const j = await r.json();
      addMessage('bot', JSON.stringify(j, null, 2));
    } else if (m === 'json') {
      const jtext = document.getElementById('json').value;
      let payload = {};
      try { payload = JSON.parse(jtext); } catch (e) { return alert('Invalid JSON'); }
      // wrap under 'values' key to match /predict/json signature
      const body = { values: payload, gender: payload.Gender || payload.gender }; 
      const r = await fetch('/predict/json', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const j = await r.json();
      addMessage('bot', JSON.stringify(j, null, 2));
    }
  } catch (e) {
    addMessage('bot', 'Error: ' + e.toString());
  }
});