
REFERENCE_RANGES = {
    "hemoglobin": {"unit": "g/dL", "min": 13.0, "max": 17.0},
    "glucose_fasting": {"unit": "mg/dL", "min": 70, "max": 99},
    "cholesterol_total": {"unit": "mg/dL", "min": 0, "max": 200},
    "blood_pressure_systolic": {"unit": "mmHg", "min": 90, "max": 120},
    "blood_pressure_diastolic": {"unit": "mmHg", "min": 60, "max": 80},
    "platelets": {"unit": "cells/mcL", "min": 150000, "max": 450000}
}
