# Blood Report Classifier - Chatbot

A production-ready AI multi-model system for classifying blood report parameters as **Low**, **Normal**, or **High**.

## Features

✅ **20 Blood Parameters** classified with gender-specific logic for Haemoglobin  
✅ **Multiple Input Formats**: PDF, Image (OCR), JSON, or raw text  
✅ **Two Classification Methods**:
   - Rule-based (deterministic thresholds)
   - ML-based (Random Forest per-parameter classifiers + overall health classifier)
  
✅ **Overall Health Status** derived from parameter labels  
✅ **Web Chat UI** - upload reports and get instant analysis  
✅ **REST API** - integrate with other systems  
✅ **Comprehensive Testing** - 7 passing unit tests  

## Installation

### Requirements
- Python 3.8+
- pip

### Setup

```bash
# Clone or navigate to the project directory
cd Model_1_Enhanced_Data_Cleaning

# Install dependencies
pip install fastapi uvicorn python-multipart pandas numpy scikit-learn

# Optional: OCR support (for PDF/image uploads)
pip install pytesseract pillow pdfplumber pdf2image

# (For Tesseract OCR, download from: https://github.com/UB-Mannheim/tesseract/wiki on Windows)
```

## Usage

### Run the Web Chatbot

```bash
python app.py
```

Then open your browser at: **http://127.0.0.1:8000**

You will see the chat interface where you can:
1. Select classification method (Rule-Based or ML-Based)
2. Upload a blood report (PDF, image, or JSON)
3. View per-parameter classifications (Low/Normal/High)
4. See overall health status

### Run Tests

```bash
python tests/run_tests.py
```

### Use the API Programmatically

```python
from blood_report_classifier import (
    generate_synthetic_data,
    train_per_parameter_classifiers,
    predict_report,
)

# Generate and train
df = generate_synthetic_data(n_samples=1500)
models, reports = train_per_parameter_classifiers(df)

# Predict
result = predict_report(
    {"Haemoglobin": 13.2, "FBS": 95, "HDL": 55},
    gender="M",
    models=models,
    method="ml"  # or "rule"
)
print(result)
```

### REST API Endpoints

**GET `/`** - Serves the web chat UI

**POST `/predict/json`**
```bash
curl -X POST "http://127.0.0.1:8000/predict/json" \
  -H "Content-Type: application/json" \
  -d '{
    "values": {"Haemoglobin": 13.2, "FBS": 95},
    "gender": "M",
    "method": "rule"
  }'
```

**POST `/predict/text`**
```bash
curl -X POST "http://127.0.0.1:8000/predict/text" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Sex: M\nHb: 13.2 g/dL\nFBS: 95 mg/dL",
    "method": "rule"
  }'
```

**POST `/predict/file`**
```bash
curl -X POST "http://127.0.0.1:8000/predict/file" \
  -F "file=@blood_report.pdf" \
  -F "method=rule"
```

## Architecture

### Core Modules

- **`blood_report_classifier.py`** - Main classifier with:
  - Classification rules per parameter
  - Synthetic data generation
  - Preprocessing (outlier capping, imputation)
  - Per-parameter Random Forest classifiers (stratified splits)
  - Overall health classifier
  - OCR/text parsing utilities
  - Chat prediction interface

- **`app.py`** - FastAPI REST server and web UI
  - Serves interactive chat UI at `/`
  - Trains models on startup
  - Exposes `/predict/*` endpoints
  - Supports file uploads (PDF, image) with OCR

- **`tests/`** - Comprehensive test suite
  - `test_blood_report_classifier.py` - Core classifier tests
  - `test_ocr_parsing.py` - OCR and parsing tests
  - `test_api.py` - REST API endpoint tests
  - `run_tests.py` - Lightweight test runner (no pytest required)

## Parameters Classified

1. Haemoglobin (gender-specific)
2. RBC count
3. WBC count
4. Platelet count
5. Haematocrit (PCV)
6. Fasting Blood Sugar (FBS)
7. Post-Prandial Blood Sugar (PPBS)
8. Total Cholesterol
9. LDL (Bad Cholesterol)
10. HDL (Good Cholesterol)
11. Creatinine
12. Blood Urea (BUN)
13. Uric Acid
14. SGOT (AST)
15. SGPT (ALT)
16. ALP (Alkaline Phosphatase)
17. Total Bilirubin
18. Direct Bilirubin
19. Albumin
20. Total Protein

## Reference Ranges

All 20 parameters use clinically validated reference ranges:
- **Haemoglobin**: Varies by gender (F: 12-15 g/dL, M: 13-17 g/dL)
- **Cholesterol**: Normal < 200, Borderline 200-239, High ≥ 240 mg/dL
- **Blood Sugar**: FBS Normal 70-99, PPBS Normal < 140 mg/dL
- **Liver Enzymes**: SGOT/SGPT/ALP Normal ranges
- **Kidney Function**: Creatinine, BUN thresholds
- And more (see `THRESHOLDS` in `blood_report_classifier.py`)

## ML Model Details

- **Per-Parameter Classifiers**: Random Forest (150 estimators)
- **Overall Health Classifier**: Random Forest (200 estimators) + StandardScaler pipeline
- **Stratified Splitting**: 75% train, 25% test, maintains class distribution
- **Feature Scaling**: StandardScaler applied to overall model
- **Class Balancing**: `class_weight="balanced"` for imbalanced classes
- **Feature Importances**: Top predictors for overall health derived from model

## Example Output

```json
{
  "values": {
    "Haemoglobin": 13.2,
    "FBS": 95,
    "HDL": 55,
    ...
  },
  "gender": "M",
  "per_parameter_labels": {
    "Haemoglobin": "Normal",
    "FBS": "Normal",
    "HDL": "Normal",
    ...
  },
  "overall_label_rule": "Normal",
  "overall_label_ml": "Normal"
}
```

## Limitations & Future Work

- OCR quality depends on image resolution and PDF text extraction capability
- Some parameters may be missing from parsed reports (gracefully handled as `Normal`)
- ML models trained on synthetic data; real-world data would improve accuracy
- File size limits can be set for production deployment
- Rate limiting and authentication recommended for production APIs

## License

This project is provided for educational and medical research purposes.
