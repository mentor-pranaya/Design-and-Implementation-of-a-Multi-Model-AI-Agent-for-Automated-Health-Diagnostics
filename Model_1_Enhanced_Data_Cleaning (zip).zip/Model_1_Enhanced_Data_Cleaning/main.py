
from data_cleaning import clean_patient_data
from model_1_checker import run_model_1

raw_report = {
    "hemoglobin": "12.5 g/dL",
    "glucose_fasting": "110 mg/dL",
    "cholesterol_total": "210",
    "blood_pressure_systolic": "135 mmHg",
    "blood_pressure_diastolic": "85",
    "platelets": ""
}

cleaned_data, errors = clean_patient_data(raw_report)
results = run_model_1(cleaned_data)

print("CLEANED DATA:", cleaned_data)
print("DATA ISSUES:", errors)
print("\nMODEL-1 RESULTS\n")

for k, v in results.items():
    print(k.upper(), v)
