from blood_report_classifier import parse_report_text, process_input_source


def test_parse_simple_text():
    sample_text = """
    Patient Name: John Doe
    Sex: M
    Hb: 13.5 g/dL
    WBC Count: 7,800 /uL
    Platelet count: 250000 /uL
    FBS: 92 mg/dL
    LDL: 120 mg/dL
    HDL: 45 mg/dL
    Creatinine: 1.05 mg/dL
    """

    values, gender = parse_report_text(sample_text)
    assert gender == "M"
    assert abs(values["Haemoglobin"] - 13.5) < 1e-6
    assert int(values["WBC_count"]) == 7800
    assert int(values["Platelet_count"]) == 250000
    assert int(values["FBS"]) == 92
    assert int(values["LDL"]) == 120
    assert int(values["HDL"]) == 45
    assert abs(values["Creatinine"] - 1.05) < 1e-6


def test_process_input_dict():
    src = {"Haemoglobin": 12.2, "Gender": "F", "FBS": 85}
    vals, gender = process_input_source(src)
    assert gender == "F"
    assert vals["Haemoglobin"] == 12.2
    assert vals["FBS"] == 85
