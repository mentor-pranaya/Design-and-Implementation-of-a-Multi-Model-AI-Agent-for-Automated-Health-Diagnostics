import importlib
import sys
import traceback
import os

# Ensure both project root and tests directory are on sys.path so imports resolve
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

# Discover all test_*.py files in this directory
import glob

test_files = glob.glob(os.path.join(os.path.dirname(__file__), "test_*.py"))
all_tests = []
for tf in test_files:
    module_name = os.path.splitext(os.path.basename(tf))[0]
    try:
        mod = importlib.import_module(module_name)
    except Exception as e:
        print(f"Failed to import {module_name}: {e}")
        sys.exit(1)
    test_funcs = [getattr(mod, attr) for attr in dir(mod) if attr.startswith("test_")]
    all_tests.extend(test_funcs)

failures = []
for func in all_tests:
    try:
        print(f"Running {func.__name__}...")
        func()
        print(f"{func.__name__}: PASS\n")
    except Exception as e:
        print(f"{func.__name__}: FAIL")
        traceback.print_exc()
        failures.append((func.__name__, e))

print("Summary:")
print(f"Total: {len(all_tests)}, Passed: {len(all_tests)-len(failures)}, Failed: {len(failures)}")
if failures:
    sys.exit(1)
else:
    sys.exit(0)