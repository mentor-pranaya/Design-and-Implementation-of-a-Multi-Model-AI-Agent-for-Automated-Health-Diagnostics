import numpy as np
import pandas as pd
from blood_report_classifier import (
    generate_synthetic_data,
    train_per_parameter_classifiers,
    train_overall_classifier,
    classify_param,
    predict_report,
    PARAMETERS,
)


def test_generate_and_train_runs():
    df = generate_synthetic_data(n_samples=300)
    models, reports = train_per_parameter_classifiers(df)
    # Ensure we have models for all parameters
    assert set(models.keys()) == set(PARAMETERS)
    assert set(reports.keys()) == set(PARAMETERS)


def test_classify_haemoglobin_gender_edges():
    assert classify_param("Haemoglobin", 11.9, gender="F") == "Low"
    assert classify_param("Haemoglobin", 12.0, gender="F") == "Normal"
    assert classify_param("Haemoglobin", 15.1, gender="F") == "High"

    assert classify_param("Haemoglobin", 12.9, gender="M") == "Low"
    assert classify_param("Haemoglobin", 13.0, gender="M") == "Normal"
    assert classify_param("Haemoglobin", 17.1, gender="M") == "High"


def test_predict_report_rule_and_ml():
    df = generate_synthetic_data(n_samples=500)
    models, reports = train_per_parameter_classifiers(df)

    sample = df.sample(1, random_state=2).to_dict(orient="records")[0]
    sample_gender = sample["Gender"]
    sample_values = {p: sample[p] for p in PARAMETERS}

    rule_pred = predict_report(sample_values, gender=sample_gender, method="rule")
    assert isinstance(rule_pred, dict)
    assert set(rule_pred.keys()) == set(PARAMETERS)

    ml_pred = predict_report(sample_values, gender=sample_gender, models=models, method="ml")
    assert isinstance(ml_pred, dict)
    assert set(ml_pred.keys()) == set(PARAMETERS)


def test_stratify_fallback_does_not_raise():
    # Create a dataset where one label is extremely rare for a parameter to force fallback
    df = generate_synthetic_data(n_samples=200)
    # Force almost all Platelet_count labels to 'Normal' and only 1 'High'
    df["Platelet_count"] = 250000
    df.loc[df.index[0], "Platelet_count"] = 1000000  # extreme high
    # Recompute labels for that column
    df["Platelet_count_label"] = df.apply(lambda r: classify_param("Platelet_count", r["Platelet_count"], r.get("Gender")), axis=1)

    # This should not raise
    models, reports = train_per_parameter_classifiers(df)
    assert "Platelet_count" in models


