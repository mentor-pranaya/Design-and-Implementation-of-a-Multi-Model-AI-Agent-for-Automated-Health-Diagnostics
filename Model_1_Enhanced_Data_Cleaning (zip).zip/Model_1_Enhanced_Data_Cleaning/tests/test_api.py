def test_api_endpoints():
    try:
        from fastapi.testclient import TestClient
        from app import app
    except Exception:
        # FastAPI or TestClient not available in environment; skip the API tests
        return

    client = TestClient(app)

    # Health check
    r = client.get("/")
    assert r.status_code == 200
    assert "text/html" in r.headers.get("content-type", "")

    # JSON predict (rule)
    payload = {"values": {"Haemoglobin": 13.2, "FBS": 95, "HDL": 55}, "gender": "M", "method": "rule"}
    r = client.post("/predict/json", json=payload)
    assert r.status_code == 200
    resp = r.json()
    assert "per_parameter_labels" in resp
    assert resp["gender"] == "M"

    # Text predict
    text = """
    Sex: F
    Hb: 11.2 g/dL
    FBS: 140
    HDL: 35
    """
    r = client.post("/predict/text", json={"text": text, "method": "rule"})
    assert r.status_code == 200
    resp = r.json()
    assert resp["gender"] == "F"
    assert resp["per_parameter_labels"]["Haemoglobin"] == "Low"
    assert resp["per_parameter_labels"]["HDL"] == "Low"